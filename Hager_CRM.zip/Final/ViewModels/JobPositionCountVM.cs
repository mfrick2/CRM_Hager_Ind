﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Hager_Ind_CRM.Models;

namespace Hager_Ind_CRM.ViewModels
{
    public class JobPositionCountVM
    {
        public string Position { get; set; }
        public int Count { get; set; }
    }
}
