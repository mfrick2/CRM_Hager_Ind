﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hager_Ind_CRM.ViewModels
{
    public class ListOptionVM
    {
        public int ID { get; set; }
        public string DisplayText { get; set; }
    }
}
