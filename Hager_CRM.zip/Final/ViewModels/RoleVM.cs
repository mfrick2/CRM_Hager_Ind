﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hager_Ind_CRM.ViewModels
{
    public class RoleVM
    {
        public string RoleId { get; set; }

        public string RoleName { get; set; }

        public bool Assigned { get; set; }
    }
}
