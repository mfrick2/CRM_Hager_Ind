﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hager_Ind_CRM.ViewModels
{
    public class PermVM
    {
        public int PermId { get; set; }

        public string PermValue { get; set; }

        public bool Assigned { get; set; }
    }
}
