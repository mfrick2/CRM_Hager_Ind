﻿using Hager_Ind_CRM.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hager_Ind_CRM.ViewModels
{
    public class MergeVM
    {
        public Company Company1 { get; set; }
        public Company Company2 { get; set; }
    }
}
